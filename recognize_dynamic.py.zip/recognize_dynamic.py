import cv2
import face_recognition

# Initialize variables
known_faces = []
face_labels = ["Person 1", "Person 2"]
face_encodings = {}

# Open webcam
video_capture = cv2.VideoCapture(0)

while True:
    ret, frame = video_capture.read()
    if not ret:
        break

    # Convert to RGB
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Detect face locations and encodings
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings_list = face_recognition.face_encodings(rgb_frame, face_locations)

    for i, face_encoding in enumerate(face_encodings_list):
        match_found = False

        # Try to match with known faces
        for label, encoding in face_encodings.items():
            match = face_recognition.compare_faces([encoding], face_encoding)[0]
            if match:
                name = label
                match_found = True
                break

        # Assign new person if not matched
        if not match_found and len(face_encodings) < 2:
            new_label = face_labels[len(face_encodings)]
            face_encodings[new_label] = face_encoding
            name = new_label
        elif not match_found:
            name = "Unknown"

        # Draw rectangle and label
        top, right, bottom, left = face_locations[i]
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
        cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    # Show the frame
    cv2.imshow("Face Recognition", frame)

    # Press 'q' to quit
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

video_capture.release()
cv2.destroyAllWindows()
